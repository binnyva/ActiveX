import angular from 'angular';
import angularMeteor from 'angular-meteor';
import template from './snapshot_list.html';
 
class TodosListCtrl {
  constructor() {
    this.snapshots = [{
      app: 'This is task 1'
    }, {
      app: 'This is task 2'
    }, {
      app: 'This is task 3'
    }];
  }
}
 
export default angular.module('snapshot_list', [
  angularMeteor
])
  .component('snapshot_list', {
    templateUrl: 'imports/components/snapshot/snapshot_list.html',
    controller: SnapshotCtrl
  });