import Moment from 'moment';
import { Meteor } from 'meteor/meteor';
// import { Snapshot } from '../lib/collections';

Meteor.startup(function() {
	
});

