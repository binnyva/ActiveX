import { Mongo } from 'meteor/mongo';

export const Snapshot = new Mongo.Collection('Snapshot');
